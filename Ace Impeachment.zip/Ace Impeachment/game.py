import pygame
import os
import random

# --- Constants ---
WINDOW_TITLE = 'Ace Impeachment'
WIDTH, HEIGHT = 1280, 720
FPS = 60

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BROWN = (150, 75, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
PURPLE = (100, 0, 100)

# Layout
START_BUTTON_SIZE = (600, 150)
ANDREW_JOHNSON_SIZE = (300, 400)
SENATOR_SIZE = (200, 200)

# Coordinates
PLAY_BUTTON_CENTER = (WIDTH // 2, HEIGHT // 2)
NAME_PLATE_POS = (325, 450)
IMAGE_POS = (250, 30)
MAIN_TEXTBOX_POS = (750, 350)
MAIN_TEXTBOX_TITLE_POS = (800, 250)

# Courtroom Layout
BAR_POS = (20, 50)
TEXT_POS = (300, 20)
BUTTON_POS = (20, 120)

COURT_STAND_POSITIONS = [
    (550, 250), (730, 255), (370, 255), (900, 270), 
    (200, 270), (1070, 300), (20, 300)
]

# Texts
INTRO_TEXT = (
    "Welcome to Ace Impeachment.\n"
    "A game about impeaching Andrew Johnson\n\n\n\n\n"
    "Click to continue"
)

EXPLANATION_TEXT = (
    "Andrew Johnson was historically the first\n"
    "president impeached.\n\n"
    "But while impeached, Andrew Johnson\n"
    "was never removed from office.\n\n"
    "Your goal is to change that.\n\n"
    "Click to continue"
)

PRESIDENT_NAME = 'Andrew Johnson'

COURTROOM_TEXTS = [
    "Welcome to the courtroom.\n\nThese three bars show the senators' bias.\n"
    "Once a bar has reached one side, a decision will\nbe made.",
    
    "You might notice the top two bars are red and blue\n"
    "This represents a bias to Impeachment (red)\n"
    "Or Not guilty (blue).\n"
    "Don't worry about the 3rd bar, it doesn't matter...",
    
    "\n\n     But that's enough reading, let's start!",
    
    "\n\n          Click one of the options below"
]

BUTTON_OPTIONS_1 = [
    'He is nicknamed "The Tennessee Tailor," but he couldn\'t even sew up the rift between the North and South.',
    'He vetoed the Civil Rights Act of 1866, which aimed to give citizenship and equal rights to newly freed slaves.',
    'He pardoned Confederate soldiers and officials, letting them off the hook for their actions in the Civil War.',
    'He drank whiskey before delivering speeches, leading to some rather slurred and incoherent addresses.',
    'He attempted to remove Edwin Stanton as Secretary of War without Congressional approval.'
]

BUTTON_OPTIONS_2 = [
    'He believed the Tenure of Office Act was unconstitutional.',
    'He vetoed several Reconstruction Acts that he felt were too harsh, trying to rejoin the two sides from the war.',
    'He has a sweet mustache that could make even the most hardened political opponent swoon.',
    'He made efforts to improve the economy and infrastructure of the South.',
    'He can lead this country to greatness given the chance.'
]

BUTTON_OPTIONS_3 = [
    'He is a master of the veto, using it over 20 times during his presidency to show Congress who was boss.',
    'He is a talented tailor and could make a mean suit.',
    'He has a unique style of speaking, starting speeches with "fellow-citizens" and ending with "God bless you all!"'
]

BUTTON_OPTIONS_4 = [
    'Option 4',
    'Do you like Star Wars?',
    'This is boring',
    'Why are we here again?',
    'Impeach Mr. Miskinis instead'
]


class Game:
    def __init__(self):
        pygame.init()
        pygame.font.init()
        pygame.mixer.init()
        
        self.win = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption(WINDOW_TITLE)
        self.clock = pygame.time.Clock()
        self.running = True
        
        # State
        self.current_scene = 'title'
        self.click_sensor = False
        self.tutorial_step = 0
        
        # Bars: [Current Value, Color]
        self.republican_bar = [70, RED]
        self.democrat_bar = [30, BLUE]
        self.third_party_bar = [0, GREEN]
        
        # Button Texts
        self.current_button_texts = [
            random.choice(BUTTON_OPTIONS_1),
            random.choice(BUTTON_OPTIONS_2),
            random.choice(BUTTON_OPTIONS_3),
            random.choice(BUTTON_OPTIONS_4)
        ]
        
        self.load_assets()
        self.setup_fonts()

    def load_assets(self):
        """Loads all game images."""
        self.assets = {}
        try:
            self.assets['title_screen'] = self.load_image('TitleScreen.png', WIDTH, HEIGHT)
            self.assets['court_single'] = self.load_image('CourtSingle.png', WIDTH, HEIGHT)
            self.assets['court_stands'] = self.load_image('CourtStands.png', WIDTH, HEIGHT)
            
            self.assets['play_button'] = self.load_image('start.gif', *START_BUTTON_SIZE)
            self.assets['andrew_johnson'] = self.load_image('andrewjohnson.gif', *ANDREW_JOHNSON_SIZE)
            self.assets['red_senator'] = self.load_image('RedGuy.gif', *SENATOR_SIZE)
            self.assets['blue_senator'] = self.load_image('BlueGuy.gif', *SENATOR_SIZE)
            
            # Court Stand Layout
            self.court_people_imgs = [
                self.assets['red_senator'], self.assets['blue_senator'], 
                self.assets['blue_senator'], self.assets['blue_senator'], 
                self.assets['blue_senator'], self.assets['red_senator'], 
                self.assets['blue_senator']
            ]
            
            # Pre-calculate rects
            self.play_button_rect = pygame.Rect(
                PLAY_BUTTON_CENTER[0] - START_BUTTON_SIZE[0] // 2,
                PLAY_BUTTON_CENTER[1] - START_BUTTON_SIZE[1] // 2,
                START_BUTTON_SIZE[0], START_BUTTON_SIZE[1]
            )
            
        except Exception as e:
            print(f"Error loading assets: {e}")
            self.running = False


    def load_image(self, filename, w, h):
        path = os.path.join('assets', filename)
        img = pygame.image.load(path)
        return pygame.transform.scale(img, (w, h))

    def setup_fonts(self):
        self.regular_font = pygame.font.SysFont('Monotype Corsiva', 35)
        self.name_font = pygame.font.SysFont('alluraregular', 35)
        self.title_font = pygame.font.SysFont('arial', 40, True)
        self.button_font = pygame.font.SysFont(None, 24)

    def randomize_buttons(self):
        self.current_button_texts = [
            random.choice(BUTTON_OPTIONS_1),
            random.choice(BUTTON_OPTIONS_2),
            random.choice(BUTTON_OPTIONS_3),
            random.choice(BUTTON_OPTIONS_4)
        ]

    def handle_court_choice(self, choice_index):
        if choice_index == 0:
            self.republican_bar[0] += random.randint(10, 20)
            self.democrat_bar[0] -= random.randint(-5, 15)
            self.third_party_bar[0] -= random.randint(-5, 15)
        elif choice_index == 1:
            self.republican_bar[0] -= random.randint(-5, 15)
            self.democrat_bar[0] += random.randint(10, 20)
            self.third_party_bar[0] -= random.randint(-5, 15)
        elif choice_index == 2:
            self.republican_bar[0] -= random.randint(-20, 20)
            self.democrat_bar[0] -= random.randint(-20, 20)
            self.third_party_bar[0] -= random.randint(-20, 20)
        elif choice_index == 3:
            self.republican_bar[0] -= random.randint(-5, 25)
            self.democrat_bar[0] -= random.randint(-5, 25)
            self.third_party_bar[0] += random.randint(10, 25)
        else:
            return # No action

        # Clamp values
        for bar in [self.republican_bar, self.democrat_bar, self.third_party_bar]:
            bar[0] = max(0, min(100, bar[0]))

        # Check endings
        if self.democrat_bar[0] >= 100:
            self.show_ending('no_impeach')
        elif self.republican_bar[0] >= 100:
            self.show_ending('impeach')
        elif self.third_party_bar[0] >= 100:
            self.show_ending('secret')
        
        self.randomize_buttons()

    def show_ending(self, ending_type):
        self.current_scene = 'ending'
        self.ending_type = ending_type
        
        if ending_type == 'impeach':
            self.win.fill(RED)
            text = (
                "And so Andrew Johnson was removed from office.\n"
                "The world was normal until the sun blew up in 2012 because the Mayans were correct.\n\n"
                "Sources:\n"
                "https://www.pbs.org/presidential/voices/\n"
                "https://www.nps.gov/anjo/learn/historyculture\n"
                "https://www.history.com/topics/american-civil-war/edwin-m-stanton"
            )
        elif ending_type == 'no_impeach':
            self.win.fill(BLUE)
            text = (
                "And so President Andrew Johnson led the United States to a peace treaty,\n"
                "People slowly forgot about their differences and the world was at peace.\n"
                "(Please note this probably would never have happened with Andrew Johnson as president)\n\n"
                "Then world war 2 hit and the other side won."
            )
        elif ending_type == 'secret':
            self.win.fill(PURPLE)
            text = (
                "And so Mr. Miskinis noticed that this project was objectively the best project\n"
                "and decided to give Jason and William a 100% on the project.\n\n\n"
                "And Mr. Miskinis was impeached."
            )
        
        self.render_multiline_text(text, self.name_font, BLACK, (50, 50), 5)
        pygame.display.update()
        pygame.time.wait(60000) # Wait 1 minute then quit
        self.running = False


    def draw_button(self, x, y, width, height, color, text, text_color):
        rect = pygame.Rect(x, y, width, height)
        pygame.draw.rect(self.win, color, rect)
        
        text_surface = self.button_font.render(text, True, text_color)
        text_x = x + (width - text_surface.get_width()) / 2
        text_y = y + (height - text_surface.get_height()) / 2
        self.win.blit(text_surface, (text_x, text_y))
        return rect

    def draw_bar(self, x, y, width, height, value, color, name, show_percentage=False):
        percentage = value / 100.0
        pygame.draw.rect(self.win, BLACK, (x, y, width, height), 2) # Outline
        
        fill_width = percentage * (width - 2)
        pygame.draw.rect(self.win, color, (x + 1, y + 1, fill_width, height - 2))
        
        # Name
        name_text = self.button_font.render(name, True, BLACK)
        name_x = x + (width - name_text.get_width()) / 2
        name_y = y - name_text.get_height() - 5
        self.win.blit(name_text, (name_x, name_y))
        
        if show_percentage:
            pct_text = self.button_font.render(f"{int(value)}%", True, BLACK)
            pct_x = x + (width - pct_text.get_width()) / 2
            pct_y = y + (height - pct_text.get_height()) / 2
            self.win.blit(pct_text, (pct_x, pct_y))

    def render_multiline_text(self, text, font, color, pos, line_spacing):
        lines = text.split('\n')
        x, y = pos
        line_height = font.size('Tg')[1] + line_spacing # 'Tg' gets approximate height
        for line in lines:
            text_surface = font.render(line, True, color)
            self.win.blit(text_surface, (x, y))
            y += line_height

    def draw(self):
        if self.current_scene == 'title':
            self.win.blit(self.assets['title_screen'], (0, 0))
            self.win.blit(self.assets['play_button'], self.play_button_rect)
            
        elif self.current_scene == 'tutorial_1':
            self.win.blit(self.assets['court_single'], (0, 0))
            self.win.blit(self.assets['andrew_johnson'], IMAGE_POS)
            
            name_text = self.name_font.render(PRESIDENT_NAME, 1, BLACK)
            self.win.blit(name_text, NAME_PLATE_POS)
            
            title_text = self.title_font.render(WINDOW_TITLE, 1, BLACK)
            self.win.blit(title_text, MAIN_TEXTBOX_TITLE_POS)
            
            text_to_show = INTRO_TEXT if self.tutorial_step <= 0 else EXPLANATION_TEXT
            self.render_multiline_text(text_to_show, self.regular_font, BLACK, MAIN_TEXTBOX_POS, 5)

        elif self.current_scene == 'tutorial_2' or self.current_scene == 'court_session':
            self.win.blit(self.assets['court_stands'], (0, 0))
            
            for i, pos in enumerate(COURT_STAND_POSITIONS):
                self.win.blit(self.court_people_imgs[i], pos)
                
            # Draw Bars
            self.draw_bar(*BAR_POS, 270, 20, self.republican_bar[0], self.republican_bar[1], 'Bias', True)
            self.draw_bar(BAR_POS[0], BAR_POS[1] + 20, 270, 20, self.democrat_bar[0], self.democrat_bar[1], '', True)
            self.draw_bar(BAR_POS[0], BAR_POS[1] + 40, 270, 20, self.third_party_bar[0], self.third_party_bar[1], '', True)
            
            # Text based on tutorial step
            text_idx = 0
            if self.current_scene == 'tutorial_2':
                text_idx = min(self.tutorial_step, len(COURTROOM_TEXTS) - 1)
                self.render_multiline_text(COURTROOM_TEXTS[text_idx], self.regular_font, WHITE, TEXT_POS, 5)
            else:
                self.render_multiline_text(COURTROOM_TEXTS[-1], self.regular_font, WHITE, TEXT_POS, 5)
                
                # Draw Buttons only in session
                self.button_rects = []
                for i in range(4):
                    rect = self.draw_button(BUTTON_POS[0], BUTTON_POS[1] + i * 30, 880, 25, BROWN, self.current_button_texts[i], BLACK)
                    self.button_rects.append(rect)

        pygame.display.update()

    def run(self):
        while self.running:
            self.clock.tick(FPS)
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                    
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    
                    if self.current_scene == 'title':
                        if self.play_button_rect.collidepoint(pos):
                            self.current_scene = 'tutorial_1'
                            self.tutorial_step = 0
                            
                    elif self.current_scene == 'tutorial_1':
                        self.tutorial_step += 1
                        if self.tutorial_step > 1:
                            self.current_scene = 'tutorial_2'
                            self.tutorial_step = 0
                            
                    elif self.current_scene == 'tutorial_2':
                        self.tutorial_step += 1
                        if self.tutorial_step >= len(COURTROOM_TEXTS) - 1:
                            self.current_scene = 'court_session'
                            
                    elif self.current_scene == 'court_session':
                        for i, rect in enumerate(self.button_rects):
                            if rect.collidepoint(pos):
                                self.handle_court_choice(i)
                                break
            
            self.draw()
        
        pygame.quit()

if __name__ == "__main__":
    game = Game()
    game.run()
